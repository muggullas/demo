# Terraform

Terraform is an open-source infrastructure as code (IaC) software tool created by HashiCorp. It allows users to define and provision infrastructure using a high-level configuration language called HashiCorp Configuration Language (HCL) or optionally JSON. Terraform manages external resources (such as public cloud infrastructure, private cloud infrastructure, network appliances, software as a service, and platform as a service) with a provider.

# Services

**Compute Instance**

**Google Cloud Storage (GCS) Bucket**

**BigQuery Dataset**

**Data-transfer**

# Environments

The configurations are structured to support multiple environments, such as dev (development) and prod (production). Each environment can have different settings and resource specifications in the files like main.tf, backend.tf, provider.tf, variables.tf and terraform.tfvars .

# prerequisites:

**GCP account with necessary permissions**

**Gitlab access**

# Usage
 
## Setting Up the Environment
 
### Steps to Create Resources

1. Clone the repository with this command git clone <https://dot-portal.de.pri.o2.com/gitlab/fastoss_b/ndl/infrastructure.git>

2. Navigate to the environment directory using the cd environment/dev. 

3. Open the main.tf file add the respected module block 

   Example: If you want to create the computeinstance,gcs-storage bucket or bigquery_data_transfer and any other service you can add like this.

 ```
   module "bigquery_data_transfer" {
    source = "../../modules/data-transfer"
    display_name = "GA4 to BigQuery"
    schedule = "every 24 hours"
    data_source_id = "google_analytics"
    project = var.project_id
  }
```

4. Go to the modules folder and open the service folders like data-transfer, gcs-stotage and others then edit the main.tf file, add your block resource block like below

```
resource "google_storage_bucket" "test" {
  name          = var.bucket_name
  location      = var.bucket_location
  force_destroy = var.bucket_force_destroy
  storage_class = var.bucket_storage_class
  uniform_bucket_level_access = var.uniform_bucket_level_access

  versioning {
    enabled = var.bucket_versioning_enabled
  }

  dynamic "lifecycle_rule" {
    for_each = var.bucket_lifecycle_rules

    content {
      condition {
        age = lifecycle_rule.value.age
      }
      action {
        type = lifecycle_rule.value.type
      }
    }
  }
}
```
5. Once the changes are done commit the code and push the code into gitlab remote repo using the below commands
 
 **git commit -m "commit message"**

 **git push**

6. Raise the merge request into master then terraform plan will be triggered so once you verified it then merge the code into master and run the apply job also manaually.

# CI/CD Pipeline

We use GitLab CI/CD for automating the Terraform workflows. The pipeline is defined in the ./gitlab-ci.yml file and includes stages for planning and applying the Terraform configurations.

**Stages**: plan stage validates and plans the Terraform changes, apply stage applies the Terraform changes to the GCP infrastructure.

**Variables**: It will define the proxy server details in http and https protocol.

**Before Script** It will export proxy server details in the both plan apply stages.

**Script**: It will  authentticate to the gcp account in dev emvironment with the key, it config the project, execute the terraform init in plan and apply stage, terraform plan in plan stage and terraform apply in apply stage.




  





